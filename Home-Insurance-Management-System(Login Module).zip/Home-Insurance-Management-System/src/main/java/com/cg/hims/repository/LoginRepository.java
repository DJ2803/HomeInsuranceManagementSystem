package com.cg.hims.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import  com.cg.hims.entities.User;
/**
 * 
 * @author Nikhil
 *User enity's repository
 *
 */
public interface LoginRepository extends JpaRepository<User,Integer> {
	

	@Query("SELECT u FROM User u WHERE u.userName = ?1")
	Optional<User> findByUsername(String username);	
	
	@Query("SELECT u FROM User u WHERE u.userName = ?1")
	User findByName(String username);	
	
	


}