package com.cg.hims.test;
import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import com.cg.hims.application.HomeInsuranceManagementSystemApplication;
import com.cg.hims.entities.User;
import com.cg.hims.exceptions.InvalidLoginCredentialsException;
import com.cg.hims.exceptions.UserNameAlreadyExistsException;
import com.cg.hims.exceptions.UserNotFoundException;
import com.cg.hims.service.LoginService;
@Transactional
@Rollback(true)
@SpringBootTest(classes = HomeInsuranceManagementSystemApplication.class)

public class UserTest {

	@Autowired

	private LoginService loginservice;

	public User AddUser()
	{ User u = new User("numan","pavan123","pavan","kumar","pkumar@gmail.com","543217654","India","policyholder");
	return u;
	}

	/*
	 * check add user
	 */
	@Test
	public void testSignUp() throws UserNameAlreadyExistsException, UserNotFoundException 
	{ User u = new User("puman","pavan123","pavan","kumar","pkumar@gmail.com","543217654","India","policyholder");
	loginservice.signup(u);
	assertEquals("puman",loginservice.getUserById(u.getUserId()).getUserName());
	assertEquals("pavan123",loginservice.getUserById(u.getUserId()).getPassword());
	}




	/*
	 * check user login
	 */
	@Test
	public void login() throws  InvalidLoginCredentialsException, UserNameAlreadyExistsException, UserNotFoundException
	{  User u = new User("ouman","pavan123","pavan","kumar","pkumar@gmail.com","543217654","India","policyholder");

	String un=u.getUserName();
	String p=u.getPassword();
	loginservice.signup(u);
	loginservice.AuthenticateUser(un,p); 
	assertEquals("ouman",loginservice.getUserById(u.getUserId()).getUserName());
	assertEquals("pavan123",loginservice.getUserById(u.getUserId()).getPassword());

	}


	/*
	 * check change Password
	 */
	@Test 
	public void testChangePassword() throws UserNotFoundException, UserNameAlreadyExistsException 
	{   User u = new User("an","pavan123","pavan","kumar","pkumar@gmail.com","543217654","India","policyholder");
	loginservice.signup(u);
	String un=u.getUserName();
	String newpwd = "newpwd";
	loginservice.changePassword(un,newpwd);
	assertEquals("newpwd",loginservice.getUserById(u.getUserId()).getPassword());
	}



}