package com.cg.hims.test;

public class AdminTest {

}
