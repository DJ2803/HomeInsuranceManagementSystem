package com.cg.hims.exceptions;

public class PolicyNotFoundException extends Exception {

	public PolicyNotFoundException(String message) {
		// TODO Auto-generated constructor stub
	}

}
